-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: farm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `comment_date` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `member_id` bigint DEFAULT NULL,
  `post_id` bigint DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5my97to6xmqeuycmeelttgj44` (`member_id`),
  KEY `FKh4c7lvsc298whoyd4w9ta25cr` (`post_id`),
  CONSTRAINT `FK5my97to6xmqeuycmeelttgj44` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKh4c7lvsc298whoyd4w9ta25cr` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES ('2024-06-20 21:38:10.856000',2,6,18,'2024-06-20 22:29:25.532000','{\r\n    \"content\": \"테스트 댓글 수정\"\r\n}'),('2024-06-20 21:44:07.441000',3,6,18,'2024-06-20 21:44:07.441000','테스트용 댓글내용'),('2024-06-20 21:44:17.607000',4,6,18,'2024-06-20 21:44:17.607000','테스트용 댓글내용'),('2024-06-20 21:44:21.531000',5,6,18,'2024-06-20 21:44:21.531000','테스트용 댓글내용'),('2024-06-20 21:44:25.812000',6,6,18,'2024-06-20 21:44:25.812000','테스트용 댓글내용'),('2024-06-20 21:46:47.073000',7,6,17,'2024-06-20 21:46:47.073000','테스트용 댓글내용'),('2024-06-20 22:07:34.986000',8,6,17,'2024-06-20 22:07:34.986000','{\r\n    \"content\": \"테스트 댓글 IN 17번 글\",\r\n    \"member_id\": 6,\r\n    \"post_id\": 17, \r\n    \"comment_date\": \"2024-06-20 19:28:39.907000\",\r\n    \"update_date\": \"2024-06-20 19:28:39.907000\"\r\n}\r\n'),('2024-06-20 22:25:17.008000',9,6,17,'2024-06-20 22:25:17.008000','{\r\n    \"content\": \"테스트 댓글 IN 17번 글\",\r\n    \"member_id\": 6,\r\n    \"post_id\": 17\r\n}\r\n'),('2024-06-20 22:25:42.067000',10,6,17,'2024-06-20 22:25:42.067000','{\r\n    \"content\": \"테스트 댓글 IN 17번 글222\",\r\n    \"member_id\": 6,\r\n    \"post_id\": 17\r\n}\r\n');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21  0:18:27
