-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: farm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `view_count` int NOT NULL,
  `member_id` bigint DEFAULT NULL,
  `post_date` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL AUTO_INCREMENT,
  `update_date` datetime(6) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `FK3vu9977d08lqidrhcrqts8e1r` (`member_id`),
  CONSTRAINT `FK3vu9977d08lqidrhcrqts8e1r` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (0,1,'2024-06-20 18:35:24.556000',1,'2024-06-20 18:35:24.556000','community','게시글 내용 1','twobeercat','게시글 제목 1 community'),(0,1,'2024-06-20 18:36:34.701000',2,'2024-06-20 18:36:34.701000','community','게시글 내용 2','twobeercat','게시글 제목 2 community'),(0,1,'2024-06-20 18:37:19.612000',3,'2024-06-20 18:37:19.612000','community','게시글 내용 3','twobeercat','게시글 제목 3 community'),(0,1,'2024-06-20 18:37:25.990000',4,'2024-06-20 18:37:25.990000','community','게시글 내용 4','twobeercat','게시글 제목 4 community'),(0,1,'2024-06-20 18:37:31.513000',5,'2024-06-20 18:37:31.513000','community','게시글 내용 5','twobeercat','게시글 제목 5 community'),(0,1,'2024-06-20 19:22:14.696000',6,'2024-06-20 19:22:14.696000','community','게시글 내용 6','twobeercat','게시글 제목 6 community'),(0,1,'2024-06-20 19:22:25.824000',7,'2024-06-20 19:22:25.824000','community','게시글 내용 7','twobeercat','게시글 제목 7 community'),(0,1,'2024-06-20 19:22:29.833000',8,'2024-06-20 19:22:29.833000','community','게시글 내용 8','twobeercat','게시글 제목 8 community'),(0,1,'2024-06-20 19:22:38.377000',9,'2024-06-20 19:22:38.377000','community','게시글 내용 9','twobeercat','게시글 제목 9 community'),(0,1,'2024-06-20 19:22:44.410000',10,'2024-06-20 19:22:44.410000','community','게시글 내용 10','twobeercat','게시글 제목 10 community'),(0,6,'2024-06-20 19:27:37.841000',12,'2024-06-20 19:27:37.841000','community','제니 게시글 내용 1','jenny','제니 게시글 제목 1 community'),(0,6,'2024-06-20 19:28:10.291000',13,'2024-06-20 19:28:10.291000','community','제니 게시글 내용 2','jenny','제니 게시글 제목 2 community'),(0,6,'2024-06-20 19:28:16.411000',14,'2024-06-20 19:28:16.411000','community','제니 게시글 내용 3','jenny','제니 게시글 제목 3 community'),(0,6,'2024-06-20 19:28:21.013000',15,'2024-06-20 19:28:21.013000','community','제니 게시글 내용 4','jenny','제니 게시글 제목 4 community'),(0,6,'2024-06-20 19:28:25.776000',16,'2024-06-20 19:28:25.776000','community','제니 게시글 내용 5','jenny','제니 게시글 제목 5 community'),(0,6,'2024-06-20 19:28:30.305000',17,'2024-06-20 19:28:30.305000','community','제니 게시글 내용 6','jenny','제니 게시글 제목 6 community'),(0,6,'2024-06-20 19:28:39.907000',18,'2024-06-20 21:27:39.333000',NULL,'제니 게시글 내용 7 수정수정','jenny','제니 게시글 제목 7 수정'),(0,6,'2024-06-20 22:43:21.576000',22,'2024-06-20 22:43:21.576000','faq','제니 게시글 내용 1','jenny','제니 게시글 제목 1 faq'),(0,6,'2024-06-20 22:43:29.487000',23,'2024-06-20 22:43:29.487000','faq','제니 게시글 내용 2','jenny','제니 게시글 제목 2 faq'),(0,6,'2024-06-20 22:43:35.477000',24,'2024-06-20 22:43:35.477000','faq','제니 게시글 내용 3','jenny','제니 게시글 제목 3 faq'),(0,6,'2024-06-20 22:43:40.443000',25,'2024-06-20 22:43:40.443000','faq','제니 게시글 내용 4','jenny','제니 게시글 제목 4 faq'),(0,6,'2024-06-20 22:43:46.132000',26,'2024-06-20 22:43:46.132000','faq','제니 게시글 내용 5','jenny','제니 게시글 제목 5 faq'),(0,6,'2024-06-20 22:44:00.536000',27,'2024-06-20 22:44:00.536000','qna','제니 게시글 내용 1','jenny','제니 게시글 제목 1 qna'),(0,6,'2024-06-20 22:44:04.918000',28,'2024-06-20 22:44:04.918000','qna','제니 게시글 내용 2','jenny','제니 게시글 제목 2 qna'),(0,6,'2024-06-20 22:44:09.816000',29,'2024-06-20 22:44:09.816000','qna','제니 게시글 내용 3','jenny','제니 게시글 제목 3 qna'),(0,6,'2024-06-20 22:44:14.509000',30,'2024-06-20 22:44:14.509000','qna','제니 게시글 내용 4','jenny','제니 게시글 제목 4 qna'),(0,6,'2024-06-20 22:44:20.028000',31,'2024-06-20 22:44:20.028000','qna','제니 게시글 내용 5','jenny','제니 게시글 제목 5 qna'),(0,6,'2024-06-20 23:10:31.180000',32,'2024-06-20 23:10:31.180000','notice','제니 게시글  notice 내용 1','jenny','제니 게시글 notice 제목 1'),(0,6,'2024-06-20 23:10:39.695000',33,'2024-06-20 23:10:39.695000','notice','제니 게시글  notice 내용 2','jenny','제니 게시글 notice 제목 2'),(0,6,'2024-06-20 23:10:44.483000',34,'2024-06-20 23:10:44.483000','notice','제니 게시글  notice 내용 3','jenny','제니 게시글 notice 제목 3'),(0,6,'2024-06-20 23:10:49.346000',35,'2024-06-20 23:10:49.346000','notice','제니 게시글  notice 내용 4','jenny','제니 게시글 notice 제목 4'),(0,6,'2024-06-20 23:10:54.636000',36,'2024-06-20 23:10:54.636000','notice','제니 게시글  notice 내용 5','jenny','제니 게시글 notice 제목 5'),(0,6,'2024-06-20 23:11:25.659000',37,'2024-06-20 23:11:25.659000','free','제니 게시글  free 내용 1','jenny','제니 게시글 free 제목 1'),(0,6,'2024-06-20 23:11:33.047000',38,'2024-06-20 23:11:33.047000','free','제니 게시글  free 내용 2','jenny','제니 게시글 free 제목 2'),(0,6,'2024-06-20 23:11:37.244000',39,'2024-06-20 23:11:37.244000','free','제니 게시글  free 내용 3','jenny','제니 게시글 free 제목 3'),(0,6,'2024-06-20 23:11:42.646000',40,'2024-06-20 23:11:42.646000','free','제니 게시글  free 내용 4','jenny','제니 게시글 free 제목 4'),(0,6,'2024-06-20 23:11:48.535000',41,'2024-06-20 23:11:48.535000','free','제니 게시글  free 내용 5','jenny','제니 게시글 free 제목 5'),(0,6,'2024-06-20 23:12:03.700000',42,'2024-06-20 23:12:03.700000','market','제니 게시글  market 내용 1','jenny','제니 게시글 market 제목 1'),(0,6,'2024-06-20 23:12:09.758000',43,'2024-06-20 23:12:09.758000','market','제니 게시글  market 내용 2','jenny','제니 게시글 market 제목 2'),(0,6,'2024-06-20 23:12:15.207000',44,'2024-06-20 23:12:15.207000','market','제니 게시글  market 내용 3','jenny','제니 게시글 market 제목 3'),(0,6,'2024-06-20 23:12:19.720000',45,'2024-06-20 23:12:19.720000','market','제니 게시글  market 내용 4','jenny','제니 게시글 market 제목 4'),(0,6,'2024-06-20 23:12:23.681000',46,'2024-06-20 23:12:23.681000','market','제니 게시글  market 내용 5','jenny','제니 게시글 market 제목 5');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21  0:18:27
